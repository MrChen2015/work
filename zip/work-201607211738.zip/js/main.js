(function() {
  (function(x, y) {
    return alert(x + y);
  });

}).call(this);
